import {
  _ as n,
  o as a,
  c as r,
  a as e,
  w as o,
  v as i,
} from "./index.a3b231e4.js";
const c = "http://45.56.71.218:8080/contacts",
  u = {
    data() {
      return {
        firstName: "",
        lastName: "",
        middleName: "",
        email: "",
        mobileNumber: "",
      };
    },
    methods: {
      doSave() {
        fetch(c, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            firstName: this.firstName,
            lastName: this.lastName,
            middleName: this.middleName,
            email: this.email,
            mobileNumber: this.mobileNumber,
          }),
        }).then(function (d) {
          d.status != 200 ||
            (alert("Saved"),
            (this.firstName = ""),
            (this.lastName = ""),
            (this.middleName = ""),
            (this.email = ""),
            (this.mobileNumber = ""));
        });
      },
    },
  },
  p = { class: "container" },
  _ = { class: "row" },
  N = { class: "col-md-6" },
  h = { class: "col-md-6" },
  v = e("br", null, null, -1),
  b = { class: "row" },
  f = { class: "col-md-6" },
  x = e("div", { class: "col-md-6" }, null, -1),
  y = e("br", null, null, -1),
  w = { class: "row" },
  S = { class: "col-md-6" },
  V = { class: "col-md-6" },
  U = e("br", null, null, -1),
  k = { class: "row" },
  B = { class: "col-md-6" },
  M = e("div", { class: "col-md-6" }, null, -1);
function T(d, s, A, C, l, m) {
  return (
    a(),
    r("div", p, [
      e("div", _, [
        e("div", N, [
          o(
            e(
              "input",
              {
                type: "text",
                class: "form-control",
                "onUpdate:modelValue":
                  s[0] || (s[0] = (t) => (l.firstName = t)),
                placeholder: "First name",
              },
              null,
              512
            ),
            [[i, l.firstName]]
          ),
        ]),
        e("div", h, [
          o(
            e(
              "input",
              {
                type: "text",
                class: "form-control",
                "onUpdate:modelValue": s[1] || (s[1] = (t) => (l.lastName = t)),
                placeholder: "Last name",
              },
              null,
              512
            ),
            [[i, l.lastName]]
          ),
        ]),
      ]),
      v,
      e("div", b, [
        e("div", f, [
          o(
            e(
              "input",
              {
                type: "text",
                class: "form-control",
                "onUpdate:modelValue":
                  s[2] || (s[2] = (t) => (l.middleName = t)),
                placeholder: "Middle name",
              },
              null,
              512
            ),
            [[i, l.middleName]]
          ),
        ]),
        x,
      ]),
      y,
      e("div", w, [
        e("div", S, [
          o(
            e(
              "input",
              {
                type: "text",
                class: "form-control",
                "onUpdate:modelValue": s[3] || (s[3] = (t) => (l.email = t)),
                placeholder: "Email Address",
              },
              null,
              512
            ),
            [[i, l.email]]
          ),
        ]),
        e("div", V, [
          o(
            e(
              "input",
              {
                type: "text",
                class: "form-control",
                "onUpdate:modelValue":
                  s[4] || (s[4] = (t) => (l.mobileNumber = t)),
                placeholder: "Mobile Number",
              },
              null,
              512
            ),
            [[i, l.mobileNumber]]
          ),
        ]),
      ]),
      U,
      e("div", k, [
        e("div", B, [
          e(
            "button",
            {
              onClick: s[5] || (s[5] = (...t) => m.doSave && m.doSave(...t)),
              class: "btn btn-primary",
            },
            "Save"
          ),
        ]),
        M,
      ]),
    ])
  );
}
var L = n(u, [["render", T]]);
export { L as default };
